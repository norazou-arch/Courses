# Courses

Application personnelle de courses avec :
- budget mensuel de 600 € ;
- nouveau compteur automatique chaque mois, avec conservation de l'historique ;
- liste de courses modifiable et cases à cocher ;
- liste permanente d'idées repas.

Les données sont enregistrées localement dans le navigateur de l'appareil.

## GitHub Pages
Dépose tous les fichiers à la racine du dépôt. Dans Settings > Pages, sélectionne Deploy from a branch, puis `main` et `/(root)`.
