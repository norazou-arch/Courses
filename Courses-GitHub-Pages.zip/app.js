const BUDGET=600;
const KEYS={expenses:"courses_expenses_v2",items:"courses_items_v2",meals:"courses_meals_v2"};
const load=k=>{try{return JSON.parse(localStorage.getItem(k)||"[]")}catch{return []}};
const save=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
let expenses=load(KEYS.expenses),items=load(KEYS.items),meals=load(KEYS.meals),filter="all";
const euro=n=>new Intl.NumberFormat("fr-FR",{style:"currency",currency:"EUR"}).format(n);
const monthKey=(d=new Date())=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`;
const monthName=k=>{let [y,m]=k.split("-");return new Date(+y,+m-1,1).toLocaleDateString("fr-FR",{month:"long",year:"numeric"})};
const esc=s=>{let d=document.createElement("div");d.textContent=s;return d.innerHTML};

document.querySelectorAll(".tabs button").forEach(b=>b.onclick=()=>{
 document.querySelectorAll(".tabs button,.page").forEach(x=>x.classList.remove("active"));b.classList.add("active");document.getElementById(b.dataset.tab).classList.add("active");
});

function renderBudget(){
 const mk=monthKey(),current=expenses.filter(e=>e.month===mk),spent=current.reduce((a,e)=>a+e.amount,0),remaining=BUDGET-spent,pct=spent/BUDGET*100;
 document.getElementById("monthLabel").textContent=monthName(mk);remainingEl.textContent=euro(remaining);spentEl.textContent=euro(spent);bar.style.width=Math.min(Math.max(pct,0),100)+"%";
 document.querySelector(".hero").classList.toggle("over",remaining<0);expensesEl.innerHTML="";
 [...current].reverse().forEach(e=>{let li=document.createElement("li");li.className="row";li.innerHTML=`<div class="row-main"><span class="name">${esc(e.name)}</span><span class="meta">${new Date(e.date).toLocaleDateString("fr-FR")}</span></div><span class="amount">− ${euro(e.amount)}</span><button class="delete" aria-label="Supprimer">×</button>`;li.querySelector("button").onclick=()=>{expenses=expenses.filter(x=>x.id!==e.id);save(KEYS.expenses,expenses);renderBudget()};expensesEl.append(li)});
 document.getElementById("noExpenses").hidden=current.length>0;renderHistory();
}
const remainingEl=document.getElementById("remaining"),spentEl=document.getElementById("spent"),bar=document.getElementById("bar"),expensesEl=document.getElementById("expenses");
document.getElementById("expenseForm").onsubmit=e=>{e.preventDefault();let amount=Number(document.getElementById("expenseAmount").value),name=document.getElementById("expenseName").value.trim();if(amount>0&&name){expenses.push({id:crypto.randomUUID?.()||Date.now()+"",amount,name,date:new Date().toISOString(),month:monthKey()});save(KEYS.expenses,expenses);e.target.reset();renderBudget()}};
function renderHistory(){let groups={};expenses.forEach(e=>(groups[e.month]??=[]).push(e));let keys=Object.keys(groups).filter(k=>k!==monthKey()).sort().reverse();document.getElementById("history").innerHTML=keys.length?keys.map(k=>`<div class="history-month"><b><span>${monthName(k)}</span><span>${euro(groups[k].reduce((a,e)=>a+e.amount,0))}</span></b><small>${groups[k].length} dépense${groups[k].length>1?"s":""}</small></div>`).join(""):`<p class="empty">Pas encore d'historique.</p>`}
document.getElementById("historyToggle").onclick=()=>document.getElementById("historyCard").classList.toggle("hidden");

function renderItems(){itemsEl.innerHTML="";let shown=items.filter(i=>filter==="all"||filter==="done"&&i.done||filter==="todo"&&!i.done);shown.forEach(i=>{let li=document.createElement("li");li.className="row "+(i.done?"done":"");li.innerHTML=`<input class="check" type="checkbox" ${i.done?"checked":""}><div class="row-main"><span class="name">${esc(i.name)}</span></div><button class="delete">×</button>`;li.querySelector(".check").onchange=x=>{i.done=x.target.checked;save(KEYS.items,items);renderItems()};li.querySelector(".delete").onclick=()=>{items=items.filter(x=>x.id!==i.id);save(KEYS.items,items);renderItems()};itemsEl.append(li)});document.getElementById("noItems").hidden=shown.length>0}
const itemsEl=document.getElementById("items");document.getElementById("itemForm").onsubmit=e=>{e.preventDefault();let name=document.getElementById("itemName").value.trim();if(name){items.push({id:crypto.randomUUID?.()||Date.now()+"",name,done:false});save(KEYS.items,items);e.target.reset();renderItems()}};
document.querySelectorAll("[data-filter]").forEach(b=>b.onclick=()=>{filter=b.dataset.filter;document.querySelectorAll("[data-filter]").forEach(x=>x.classList.toggle("active",x===b));renderItems()});
document.getElementById("clearDone").onclick=()=>{items=items.filter(i=>!i.done);save(KEYS.items,items);renderItems()};

function renderMeals(){document.getElementById("mealsList").innerHTML="";meals.forEach(m=>{let li=document.createElement("li");li.className="row";li.innerHTML=`<div class="row-main"><span class="name">🍽️ ${esc(m.name)}</span></div><button class="delete">×</button>`;li.querySelector("button").onclick=()=>{meals=meals.filter(x=>x.id!==m.id);save(KEYS.meals,meals);renderMeals()};document.getElementById("mealsList").append(li)});document.getElementById("noMeals").hidden=meals.length>0}
document.getElementById("mealForm").onsubmit=e=>{e.preventDefault();let name=document.getElementById("mealName").value.trim();if(name){meals.push({id:crypto.randomUUID?.()||Date.now()+"",name});save(KEYS.meals,meals);e.target.reset();renderMeals()}};

renderBudget();renderItems();renderMeals();
